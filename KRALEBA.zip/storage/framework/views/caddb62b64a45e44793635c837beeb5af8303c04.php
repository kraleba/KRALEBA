<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Editeaza Articolul <b> <?php echo e($ware['product_name']); ?></b></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('wares.index', $customer['customer_id'])); ?>"> Renunta</a>
            </div>
        </div>
    </div>
    <br>

    <div>
        <form action="<?php echo e(route('wares.update', ['customer_id'=>$customer['customer_id'], 'ware'=>$ware['id']])); ?>"
              method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>

                

                <input type="hidden" name="customer_id" value="<?php echo e($customer['customer_id'] ?? ''); ?>">


                <select id="subcategorySelected" name="subcategory_id" onchange="showWareTemplate()"
                        class="form-control filter-control">
                    <option>Selecteaza o subcategorie</option>

                    <?php $__currentLoopData = $customer['category_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($category['name'] != 'Textile'): ?>
                            <optgroup label="<?php echo e($category['name']); ?>">
                                <?php endif; ?>
                                <?php $__currentLoopData = $customer['subcategory_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($category['category_id'] == $subcategory['category_id']): ?>
                                        <option
                                            value="<?php echo e($subcategory['id']); ?>"
                                            <?php if($ware['subcategory_id'] == $subcategory['id']): ?>
                                                selected
                                            <?php endif; ?>
                                        >
                                            <?php echo e($subcategory['name']); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                            <?php if($category['name'] == "Textile"): ?>
                                <option value="<?php echo e($category['category_id']); ?>"
                                        style="color: red"
                                        <?php if($ware['subcategory_id'] == 'Textile'): ?>
                                            selected
                                    <?php endif; ?>
                                >
                                    <?php echo e($category['name']); ?>

                                </option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <br>

            <div id="templateWare">
                <div class="col-xs-1 col-sm-12 col-md-5 show-subcategory">

                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong><i class="fa fa-asterisk" style="font-size:7px;color:red; vertical-align: top;"></i>Product
                                Name:</strong>
                            <input type="text" name="product_name" class="form-control"
                                   value="<?php echo e($ware['product_name'] ?? ''); ?>" placeholder="Product Name">
                            <?php $__errorArgs = ['Product name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong><i class="fa fa-asterisk" style="font-size:7px;color:red; vertical-align: top;"></i>Custom
                                code:</strong>
                            <input type="text" name="custom_code" class="form-control"
                                   value="<?php echo e($ware['custom_code'] ?? ''); ?>" placeholder="Custom code">
                            <?php $__errorArgs = ['Custom code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div id="textileInputs"
                         <?php if($ware['subcategory_id'] != 'Textile'): ?>
                             style="display: none"
                        <?php endif; ?>
                    >

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Description:</strong>
                                <input type="text" name="description" class="form-control"
                                       value="<?php echo e($ware['description'] ?? ''); ?>"

                                       placeholder="Description">
                                <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Composition:</strong>
                                <input type="text" name="composition" class="form-control"
                                       value="<?php echo e($ware['composition'] ?? ''); ?>" placeholder="Composition">
                                <?php $__errorArgs = ['Composition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Material
                                    :</strong>
                                <input type="text" name="material" class="form-control"
                                       value="<?php echo e($ware['material'] ?? ''); ?>"
                                       placeholder="Material ">
                                <?php $__errorArgs = ['Material '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Structure:</strong>
                                <input type="text" name="structure" class="form-control"
                                       value="<?php echo e($ware['structure'] ?? ''); ?>"
                                       placeholder="Structure">
                                <?php $__errorArgs = ['Structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Design:</strong>
                                <input type="text" name="design" class="form-control"
                                       value="<?php echo e($ware['design'] ?? ''); ?>"
                                       placeholder="Design">
                                <?php $__errorArgs = ['Design'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Weaving:</strong>
                                <input type="text" name="weaving" class="form-control"
                                       value="<?php echo e($ware['weaving'] ?? ''); ?>"
                                       placeholder="weaving">
                                <?php $__errorArgs = ['Weaving'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Color:</strong>
                                <input type="text" name="color" class="form-control"
                                       value="<?php echo e($ware['color'] ?? ''); ?>"
                                       placeholder="Color">
                                <?php $__errorArgs = ['Color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Finishing:</strong>
                                <input type="text" name="finishing" class="form-control"
                                       value="<?php echo e($ware['finishing'] ?? ''); ?>"
                                       placeholder="Finishing">
                                <?php $__errorArgs = ['Finishing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Perceived
                                    weight:</strong>
                                <input type="text" name="perceived_weight" class="form-control"
                                       value="<?php echo e($ware['perceived_weight'] ?? ''); ?>"
                                       placeholder="Perceived weight">
                                <?php $__errorArgs = ['Perceived weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Softness:</strong>
                                <input type="text" name="softness" class="form-control"
                                       value="<?php echo e($ware['softness'] ?? ''); ?>"

                                       placeholder="Softness">
                                <?php $__errorArgs = ['Softness'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Look:</strong>
                                <input type="text" name="look" class="form-control" placeholder="Look"
                                       value="<?php echo e($ware['look'] ?? ''); ?>"
                                >
                                <?php $__errorArgs = ['Look'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Grounds:</strong>
                                <input type="text" name="grounds" class="form-control"
                                       value="<?php echo e($ware['grounds'] ?? ''); ?>"
                                       placeholder="Grounds">
                                <?php $__errorArgs = ['Grounds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Weight in
                                    g/m2:</strong>
                                <input type="text" name="weight_in_g/m2" class="form-control"
                                       value="<?php echo e($ware['weight_in_g/m2'] ?? ''); ?>" placeholder="Weight in g/m2">
                                <?php $__errorArgs = ['Weight in g/m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Width
                                    (cm):</strong>
                                <input type="text" name="width" class="form-control"
                                       value="<?php echo e($ware['width'] ?? ''); ?>"
                                       placeholder="Width (cm)">
                                <?php $__errorArgs = ['Width (cm)'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Yarn number
                                    warp:</strong>
                                <input type="text" name="warp_th_per_cm" class="form-control"
                                       value="<?php echo e($ware['warp_th_per_cm'] ?? ''); ?>"
                                       placeholder="Yarn number warp">
                                <?php $__errorArgs = ['Yarn number warp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Yarn count per cm
                                    warp:</strong>
                                <input type="text" name="warp_th_per_yarn_ne" class="form-control"
                                       value="<?php echo e($ware['warp_th_per_yarn_ne'] ?? ''); ?>"
                                       placeholder="Yarn count per cm warp">
                                <?php $__errorArgs = ['Yarn count per cm warp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i> Yarn count per cm
                                    weft: </strong>
                                <input type="text" name="weft_p_per_cm" class="form-control"
                                       value="<?php echo e($ware['weft_p_per_cm'] ?? ''); ?>"
                                       placeholder="Yarn count per cm weft">
                                <?php $__errorArgs = ['Yarn count per cm weft'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Origin:</strong>
                                <input type="text" name="origin" class="form-control"
                                       value="<?php echo e($ware['origin'] ?? ''); ?>"
                                       placeholder="Origin">
                                <?php $__errorArgs = ['Origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Date:</strong>
                                <input type="text" name="date" class="form-control"
                                       value="<?php echo e($ware['date'] ?? ''); ?>"
                                       placeholder="Date">
                                <?php $__errorArgs = ['Date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong><i class="fa fa-asterisk"
                                           style="font-size:7px;color:red; vertical-align: top;"></i>Rating:</strong>
                                <input type="text" name="rating" class="form-control"
                                       value="<?php echo e($ware['rating'] ?? ''); ?>"
                                       placeholder="Rating">
                                <?php $__errorArgs = ['Rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong><i class="fa fa-asterisk"
                                       style="font-size:7px;color:red; vertical-align: top;"></i>Moneda:</strong>

                            <input type="hidden" name="coin" class="form-control" value="<?php echo e($coin['id'] ?? ''); ?>">
                            <input type="text" class="form-control"
                                   readonly="readonly"
                                   value="<?php echo e($coin['label'] ?? ''); ?>"
                                   placeholder="Moneda">
                            <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong><i class="fa fa-asterisk"
                                       style="font-size:7px;color:red; vertical-align: top;"></i>UM:</strong>
                            <select name="UM" class="form-select"
                                    aria-label="Default select example">
                                <option selected>Selecteaza UM</option>
                                <option value="ml">ml</option>
                                <option value="gr">gr</option>
                                <option value="Kg">kg</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong><i class="fa fa-asterisk"
                                       style="font-size:7px;color:red; vertical-align: top;"></i>Cantitatea:</strong>
                            <input type="text" name="amount" class="form-control"
                                   value="<?php echo e($ware['amount'] ?? ''); ?>"
                                   placeholder="Cantitatea">
                            <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong><i class="fa fa-asterisk" style="font-size:7px;color:red; vertical-align: top;"></i>Pret:</strong>
                            <input type="text" name="price" class="form-control" placeholder="Pret"
                                   value="<?php echo e($ware['price'] ?? ''); ?>"
                            >
                            <?php $__errorArgs = ['Cantitatea'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Editeaza</button>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/ware/ware_edit.blade.php ENDPATH**/ ?>