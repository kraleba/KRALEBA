<?php $__env->startSection('content'); ?>

    <h3>Articole</h3>
    <div>
        <?php if($customer_id): ?>

            <div class="row">
                <div class="col-lg-12 margin-tb">
                    <div class="pull-right">
                        <a class="btn btn-secondary" href="<?php echo e(route('wares.create', $customer_id ?? '')); ?>">
                            ADAUGA ARTICOl
                        </a>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    </div>

    <?php if($customer_id && $wares): ?>
        <div class="container ">
            <div class="row  card round3">
                <div class="col-lg-12 ">
                    <form action="<?php echo e(route('bills.create', $customer_id ?? '')); ?>">
                        <div>
                            <h3>Articole ne facturate <?php echo e($wares_count ?? ''); ?></h3>
                            <button class="btn btn-xs btn-danger btn-flat show-alert-delete-box btn-sm"
                                    data-toggle="tooltip" style="float: right">Genereaza factura
                            </button>

                        </div>
                    </form>
                </div>

            </div>
        </div>
    <?php else: ?>
        <?php echo $__env->make('ware.ware_filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <!--end filter-->
    <br>

        <?php if($wares): ?>
            <div>
                <h3> <?php echo e($filter_title ?? 'Toti clientii'); ?></h3>
            </div>
        <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <?php if($wares): ?>
        <div>
            <ul class="list-body">
                <?php $__currentLoopData = $wares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ware): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="list-group-item white-text rounded-pill" style=" border-radius: 0; height: 80px">

                        <div class="align">

                            <b><?php echo e($ware->product_name); ?> </b> /

                            <?php echo e($ware->custom_code); ?>


                            <?php if($ware->description): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($ware->description); ?>


                            <?php if($ware->date): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($ware->date); ?> /

                            
                            Curs Valutar: <?php echo e($ware->coin); ?> / 

                            UM: <?php if($ware->um): ?>

                            <?php endif; ?>
                            / Cantitate: <?php echo e($ware->amount); ?>

                        </div>

                        <div class="dropdown option-button">
                            <div class=" dropdown" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                 aria-haspopup="true" aria-expanded="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                     class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                    <path
                                        d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                                </svg>
                            </div>
                            <form
                                action="<?php echo e(route('wares.destroy', ['customer_id'=>$ware->customer_id,'ware'=>$ware->id])); ?>"
                                method="POST"
                            >
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                    <a class="dropdown-item"
                                       href="<?php echo e(route('wares.edit', ['customer_id'=>$ware->customer_id, 'ware'=>$ware->id])); ?>">
                                        Edit
                                    </a>


                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="dropdown-item">Delete</button>

                                </div>
                            </form>
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    <?php else: ?>
        <div class="alert alert-warning">
            <h5>Nici un client!</h5>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/ware/ware_index.blade.php ENDPATH**/ ?>