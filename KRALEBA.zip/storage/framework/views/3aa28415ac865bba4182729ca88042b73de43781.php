<div class="container ">
    <div class="row searchFilter card round3">

        <div class="col-lg-12 box-filter">
            <form method="get">
                <div>
                    <h4>SELECTEAZA:</h4>
                </div>

                <br>

                <div class="input-group item-left">
                    
                    <div class="filter-item1 ">
                        <select name="customer_type" id="department"
                                class="form-control rounded-pill filter-control">
                            
                            <option value=" "> Selecteaza tipul </option>
                            <option value="customer"> Beneficiar</option>
                            <option value="provider">Furnizor</option>
                        </select>
                    </div>


                    <div class="filter-item1">
                        <select name="category" id="department" class="form-control rounded-pill filter-control">

                            <option
                                value="<?php echo e($filtering_criteria['category']->category_id ?? ''); ?>"> <?php echo e($filtering_criteria['category']->name ?? '-- Selecteaza o categorie --'); ?></option>

                            <?php $__currentLoopData = $furnace_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furnace_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($furnace_category->category_id); ?>"><?php echo e($furnace_category->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               name="subcategory"
                               list="browsers"
                               placeholder="--Selecteaza o subcategorie--"
                               class="form-control filter-control rounded-pill"
                               value="<?php echo e($filtering_criteria['subcategory'] ?? ''); ?>"
                        >

                        <datalist id="browsers" class="dropdown">

                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subcategory->subcategory_id); ?>"><?php echo e($subcategory->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>

                    </div>

                </div>

                <div class="filter-item_OK ">
                    <button id="searchBtn" type="submit" class="btn btn-secondary"> OK</button>
                </div>

                <div class="pdf-style">

                    
                    
                    
                    
                </div>
            </form>

            <form>
                <div class="revert-b">
                    <button type="submit" class="btn btn-secondary">REVERT</button>
                </div>
            </form>

        </div>
        <form>
            <div class="generare">
                <button type="submit" class="btn btn-secondary">Generare pdf</button>
            </div>
        </form>
    </div>
    
</div>
<?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/ware/ware_filters.blade.php ENDPATH**/ ?>