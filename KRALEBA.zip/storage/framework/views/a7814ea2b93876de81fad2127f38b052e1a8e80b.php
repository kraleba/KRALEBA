<?php $__env->startSection('content'); ?>

    <head>
        <meta charset="UTF-8">
        <title>Facturii</title>
    </head>

    <body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h3>Facturii</h3>
                </div>
                <div class="pull-right mb-2">
                    
                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php echo $__env->make('bills.bills_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <br>

    <div>
        <h3> <?php echo e($filter_title ?? 'Toate facturile clientului X'); ?></h3>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div>

        <?php if($bills): ?>
            <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="list-group-item white-text rounded-pill" style=" border-radius: 0; height: 80px">

                    <div class="align">
                        

                        <b><?php echo e($bill->name); ?> </b> /

                        Data Facturari: <?php echo e($bill->bill_date); ?>


                        <?php if($bill->bill_number): ?>
                            /
                        <?php endif; ?>
                        Numarul Facturi: <?php echo e($bill->bill_number); ?>


                        <?php if($bill->exchange): ?>
                            /
                        <?php endif; ?>
                        Curs Valutar: <?php echo e($bill->exchange); ?>


                        <?php if($bill->TVA): ?>
                            /
                        <?php endif; ?>
                        Total incl. TVA: <?php echo e($bill->TVA); ?>


                    </div>
                    <div class="dropdown option-button">
                        <div class=" dropdown" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                             aria-haspopup="true" aria-expanded="false">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                 class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                <path
                                    d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                            </svg>
                        </div>
                        <form
                            action="<?php echo e(route('bills.destroy',['customer_id' => $bill->customer_id, 'bill' => $bill->id])); ?>"
                            method="POST">

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                <a class="dropdown-item"
                                   href="<?php echo e(route('bills.show', ['customer_id' => $bill->customer_id, 'bill' => $bill->id])); ?>">Vezi
                                    Fctura </a>

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="dropdown-item">Delete</button>

                            </div>
                        </form>
                    </div>
                </div>

                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php else: ?>
        <div class="alert alert-warning">
            <h5>Nici un client!</h5>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/bills/bills_index.blade.php ENDPATH**/ ?>