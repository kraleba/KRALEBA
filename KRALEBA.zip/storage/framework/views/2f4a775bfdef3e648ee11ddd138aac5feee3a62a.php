<div class="container ">
    <div class="row searchFilter card round3">

        <div class="col-lg-12 box-filter">
            <form method="get">
                <div>
                    <h4>SELECTEAZA:</h4>
                </div>

                <br>

                
                    









                <div class="center">
                <div class="input-group item-left">
                    <div class="filter-item1">
                        <input type='text'
                               id="find_customer"
                               name="customer_name"
                               placeholder="--Selecteaza un Client--"
                               class="form-control filter-control rounded-pill"
                        >
                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_composition"
                               row_name="composition"
                               name="textiles_composition"
                               placeholder="--Selecteaza Compozitia--"
                               class="form-control filter-control rounded-pill find_textiles_composition"
                        >
                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               id="find_material"
                               row_name="material"
                               name="textiles_material"
                               placeholder="--Selecteaza Material--"
                               class="form-control filter-control rounded-pill find_material"
                        >
                    </div>
                </div>
                <br>

                <div class="input-group item-left">
                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_design"
                               row_name="design"
                               name="textiles_design"
                               placeholder="--Selecteaza Design--"
                               class="form-control filter-control rounded-pill find_textiles_design"
                        >
                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_color"
                               row_name="color"

                               name="textiles_color"
                               placeholder="--Select Color--"
                               class="form-control filter-control rounded-pill find_textiles_color"
                        >
                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_structure"
                               row_name="structure"
                               name="textiles_structure"
                               placeholder="--Selecteaza Structure--"
                               class="form-control filter-control rounded-pill find_textiles_structure"
                        >
                    </div>
                </div>
                <br>
                
                <div class="input-group item-left">

                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_weaving"
                               row_name="weaving"
                               name="textiles_weaving"
                               placeholder="--Selecteaza Weaving--"
                               class="form-control filter-control rounded-pill find_textiles_weaving"
                        >
                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_finishing"
                               row_name="finishing"
                               name="textiles_finishing"
                               placeholder="--Selecteaza Finishing--"
                               class="form-control filter-control rounded-pill find_textiles_finishing"
                        >
                    </div>

                    <div class="filter-item1">
                        <input type='text'
                               id="find_textiles_rating"
                               row_name="rating"
                               name="textiles_rating"
                               placeholder="--Selecteaza Rating--"
                               class="form-control filter-control rounded-pill find_textiles_rating"
                        >
                    </div>
                </div>
                </div>

                <div class="filter-item_OK ">
                    <button id="searchBtn" type="submit" class="btn btn-secondary"> OK</button>
                </div>

                <div class="pdf-style">

                    
                    
                    
                    
                </div>
            </form>

            <form>
                <div class="revert-textil">
                    <button type="submit" class="btn btn-secondary">REVERT</button>
                </div>
            </form>
        </div>

    </div>
</div>









<?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/ware/textiles/customers_textile_filters.blade.php ENDPATH**/ ?>