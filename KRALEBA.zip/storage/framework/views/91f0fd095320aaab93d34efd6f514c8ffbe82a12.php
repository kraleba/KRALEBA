<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Editeazal pe <?php echo e($customers->name); ?></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('customers.index')); ?>"> Renunta</a>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>

        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>

    <form action="<?php echo e(route('customers.update',$customers->id)); ?>" method="POST">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php if($customers->type == 'provider'): ?>

            <input type="hidden" name="customer_id" value="<?php echo e($customers->id); ?>">

            <div class="col-xs-1 col-sm-12 col-md-5 show-subcategory">

                <strong id="category"
                        <?php
                            $categories = array();
                            $i = 0;
                                foreach($customers->categories as $category) {
                                    $categories[$category->category_id] =(array)$category->category_id;
                                    $i++;
                                }
                        ?>
                        customer_id="<?php echo e($customers->id); ?>"
                        categories="<?php echo e(json_encode($customers->categories)); ?>"
                >Categorii:</strong>
                <br>

                <?php $__currentLoopData = $furnace_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furnace_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="checkbox"
                           id="category_id <?php echo e($furnace_category->category_id); ?>"
                           onclick="showSubcategoryByCategoryId(<?php echo e($furnace_category->category_id); ?>, <?php echo e(json_encode($customers->categories)); ?>)"
                           name="categories_id[]"
                           value="<?php echo e($furnace_category->category_id); ?>"
                           <?php if($categories[$furnace_category->category_id] ?? ''== $furnace_category->category_id): ?>
                               checked
                        <?php endif; ?>
                    >
                    <label><?php echo e($furnace_category->name); ?></label>

                    <br>

                    <div class="card subcategory-card" id="subcategory<?php echo e($furnace_category->category_id); ?>">
                        <div id="subcategory_list<?php echo e($furnace_category->category_id); ?>"></div>

                        <div id="category_id<?php echo e($furnace_category->category_id); ?>" style="display: none">
                            <?php if($furnace_category->category_id != 8): ?>

                                <input placeholder="add subcategory" type="text"
                                       id="subcategoryLabel <?php echo e($furnace_category->category_id); ?>">
                                <input onclick="addSubcategoryForCustomersId(<?php echo e($furnace_category->category_id); ?>)"
                                       type="button" value="Add">

                            <?php endif; ?>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            <div class="col-xs-1 col-sm-12 col-md-6" style="padding-left: 130px;">

                
                
                
                
                
                
                
                

                
                


            </div>
        <?php endif; ?>
        <div id="customerOrProviderForm">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong><i class="fa fa-asterisk" style="font-size:7px;color:red; vertical-align: top;"></i>Name:</strong>
                        <input type="text" name="name" class="form-control" placeholder="Name"
                               value="<?php echo e($customers->name); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong><i class="fa fa-asterisk" style="font-size:7px;color:red; vertical-align: top;"></i>Cod:</strong>
                        <input type="number" name="uniqueCode" class="form-control" placeholder="Cod"
                               value="<?php echo e($customers->uniqueCode); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Adresa:</strong>
                        <input type="text" name="address" class="form-control" placeholder="Adresa"
                               value="<?php echo e($customers->address); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Cod Postal:</strong>
                        <input type="number" name="zipCode" class="form-control" placeholder="Cod Postal"
                               value="<?php echo e($customers->zipCode); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong><i class="fa fa-asterisk" style="font-size:7px;color:red; vertical-align: top;"></i>Oras
                            :</strong>
                        <input type="text" name="city" class="form-control" placeholder="Oras"
                               value="<?php echo e($customers->city); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <strong><i class="fa fa-asterisk"
                               style="font-size:7px;color:red; vertical-align: top;"></i>Tara:</strong>
                    <select name="country" id="department" class="form-control">
                        <option value="<?php echo e($customers->country); ?>"> <?php echo e($countries[$customers->country]); ?> </option>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i != $customers->country): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($country); ?></option>
                            <?php endif; ?>
                            <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>CIF :</strong>
                        <input type="text" name="cif" class="form-control" placeholder="CIF"
                               value="<?php echo e($customers->cif); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>OCR :</strong>
                        <input type="text" name="ocr" class="form-control" placeholder="OCR"
                               value="<?php echo e($customers->ocr); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>IBAN :</strong>
                        <input type="text" name="iban" class="form-control" placeholder="IBAN"
                               value="<?php echo e($customers->iban); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>SWIFT :</strong>
                        <input type="text" name="swift" class="form-control" placeholder="SWIFT"
                               value="<?php echo e($customers->swift); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>BANCA :</strong>
                        <input type="text" name="bank" class="form-control" placeholder="BANCA"
                               value="<?php echo e($customers->bank); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>CONTACT :</strong>
                        <input type="text" name="contact" class="form-control" placeholder="CONTACT"
                               value="<?php echo e($customers->contact); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Telefon 1:</strong>
                        <input type="number" name="phone" class="form-control" placeholder="Telefon 1"
                               value="<?php echo e($customers->phone); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Telefon 2:</strong>
                        <input type="number" name="phone2" class="form-control" placeholder="Telefon 2"
                               value="<?php echo e($customers->phone2); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>e-mail:</strong>
                        <input type="text" name="email" class="form-control" placeholder="e-mail"
                               value="<?php echo e($customers->email); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>www:</strong>
                        <input type="text" name="www" class="form-control" placeholder="www"
                               value="<?php echo e($customers->www); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Note:</strong>
                        <input class="form-control" style="height:70px" name="note" placeholder="Note"
                               value="<?php echo e($customers->note); ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Editeaza</button>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/customers/edit.blade.php ENDPATH**/ ?>