<div id="customerOrProviderForm">
    <div class="row">

        <div class="col-xs-6 col-sm-6 col-md-6 categories_area" categories="<?php echo e(json_encode($customer_categories)); ?>">

            <div class="form-group">
                <strong>Product Name</strong>
                <input type="text" name="product_name" id="template_name" class="form-control" placeholder="Product Name">
            </div>

            <?php $__currentLoopData = $customer_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-12 col-md-12 template-inputs">

                    <label><?php echo e($category->name); ?></label>
                    <input type="checkbox"
                           class="categories-box"
                           id="check_if_is_checked<?php echo e($category->category_id); ?>"
                           category_id="<?php echo e(json_encode($category->category_id)); ?>"
                    >

                    <div id="show_category_by_id<?php echo e($category->category_id); ?>" style="display: none">
                        <form id="form_customer<?php echo e($category->category_id); ?>">

                            <div class="form-group">
                                <label>Furnizor</label>
                                <input name="customer" id="customer<?php echo e($category->category_id); ?>">
                            </div>

                            <div class="form-group">
                                <label>Product Name</label>
                                <input name="product_name" id='product_name<?php echo e($category->category_id); ?>'>
                            </div>

                            <div class="form-group">
                                <label>Custom Code</label>
                                <input name="bill_number" id="custom_code<?php echo e($category->category_id); ?>">
                            </div>


                            <div class="form-group">
                                <label>Data Facturarii</label>
                                <input name="bill_date" id="bil_date<?php echo e($category->category_id); ?>">
                            </div>


                            <div class="form-group">
                                <label>Numarul Facturii</label>
                                <input name="bill_number" id="bill_number<?php echo e($category->category_id); ?>">
                            </div>

                            <div class="form-group">
                                <label>Numarul Facturii</label>
                                <input type="number" name="amount" id="amount<?php echo e($category->category_id); ?>">
                            </div>
                        </form>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" id="template_photo1" name="template_photo1">
                <input type="file" id="template_photo2" name="template_photo2">
                <input type="file" id="template_photo3" name="template_photo3">
            </div>
        </div>


        <div class="col-xs-12 col-sm-12 col-md-12 ">
            <input type="button" class="btn btn-primary child-validate" value="valideaza">
            <button type="submit" class="btn btn-primary">Renunta</button>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/products_template/product_child/template_child.blade.php ENDPATH**/ ?>