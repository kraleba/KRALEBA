<?php $__env->startSection('content'); ?>

    <div>
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-right">
                    <a class="btn btn-secondary" href="<?php echo e(route('templates.create')); ?>"> ADAUGA CLIENT</a>
                </div>
            </div>

        </div>
    </div>
    <div class="container ">
        <div class="row searchFilter-custom card round3">

            <div class="col-lg-12 box-filter">
                <form action="<?php echo e(route('customers.index')); ?>" method="get">
                    <div>
                        <h4>SELECTEAZA:</h4>
                    </div>
                    <br>

                    <br>
                    <div class="input-group item-left filter-item1">
                        <div >
                            <div>
                                <input type='text'
                                       id="find_customer"
                                       name="customer_name"
                                       placeholder="--Selecteaza un Client--"
                                       class="form-control filter-control rounded-pill"
                                >
                            </div>
                        </div>

                        <div>
                            <div>
                                <select name="customer_type" id="department"
                                        class="form-control rounded-pill filter-control">
                                    
                                    <option value="customer"> Beneficiar</option>
                                    <option value="provider">Furnizor</option>
                                </select>
                            </div>
                        </div>



                        <div>
                            <select name="category" id="department" class="form-control rounded-pill filter-control">

                                <option
                                    value="<?php echo e($filtering_criteria['category']->category_id ?? ''); ?>"> <?php echo e($filtering_criteria['category']->name ?? '-- Selecteaza o categorie --'); ?></option>







                            </select>

                        </div>

                        <div>
                            <input type='text'
                                   name="subcategory"
                                   list="browsers"
                                   placeholder="--Selecteaza o subcategorie--"
                                   class="form-control filter-control rounded-pill"
                                   value="<?php echo e($filtering_criteria['subcategory'] ?? ''); ?>"
                            >

                            <datalist id="browsers" class="dropdown">




                            </datalist>

                        </div>
                    </div>


                    <div class="filter-item_OK ">
                        <button id="searchBtn" type="submit" class="btn btn-secondary"> OK</button>
                    </div>

                    <div class="pdf-style">





                    </div>
                </form>

                <form>
                    <div class="revert-b">
                        <button type="submit" class="btn btn-secondary">REVERT</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
    <!--end filter-->
    <br>







    <br>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


        <div>
            <ul class="list-body">


                    <div class="list-group-item white-text rounded-pill" style=" border-radius: 0; height: 80px">

                        <div class="align">


                                <b>pirus </b> /


                            <a> 001-1/5 </a>



















































































                            <div class="dropdown option-button">
                                <div class=" dropdown" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                     aria-haspopup="true" aria-expanded="false">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                         class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                        <path
                                            d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                                    </svg>
                                </div>


                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                        <a class="dropdown-item"
                                           href="">Creaza Productie </a>

                                        <a class="dropdown-item"
                                           href="">Edit</a>

                                        <a class="dropdown-item" href="">
                                            Articole </a>


                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="dropdown-item">Delete</button>

                                    </div>

                            </div>
                    </div>


            </ul>
        </div>


        <div class="alert alert-warning">
            <h5>Nici un client!</h5>
        </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/products_template/template_index.blade.php ENDPATH**/ ?>