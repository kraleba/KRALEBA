<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Back</a>
    <br>
    <head>
        <meta charset="UTF-8">
        <title>Facturii</title>
    </head>

    <body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    
                </div>
                <div class="pull-right mb-2">
                    
                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>


        <br>
        <div>
            <h3> <?php echo e($filter_title ?? 'Toate facturile clientului X'); ?></h3>
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div>

            <?php if($bills): ?>
                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <table>

                        <tr>
                            <th rowspan="2"></th>
                            <th rowspan="2">Product</th>
                            <th rowspan="2">Code</th>
                            <th rowspan="2">Description</th>
                            <th colspan="4"> buc./UM</th>
                            <th colspan="2">Total fara TVA</th>
                            <th colspan="2">TVA</th>
                            <th colspan="2">Total incl. TVA</th>
                        </tr>
                        <tr>
                            <th>UM</th>
                            <th>Cantit.</th>
                            <th>Euro</th>
                            <th>Lei</th>
                            <th>Euro</th>
                            <th>Lei</th>
                            <th>Euro</th>
                            <th>Lei</th>
                            <th>Euro</th>
                            <th>Lei</th>
                        </tr>
                        <?php $i = 1;
                     $eu_wit_out_tva = 0;
                     $lei_wit_out_tva = 0;
                     $eu_tva = 0;
                     $lei_tva = 0;
                     $eu_with_tva = 0;
                     $lei_with_tva = 0;

                        ?>
                        <?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ware): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($ware['product_name']); ?></td>
                                <td><?php echo e($ware['custom_code']); ?></td>
                                <td><?php echo e($ware['description']); ?></td>
                                <td><?php echo e($ware['um']); ?></td>
                                <td><?php echo e($ware['amount']); ?></td>
                                
                                <td><?php echo e($ware['price_euro']); ?></td>
                                <td><?php echo e($ware['price_lei']); ?></td>
                                
                                <td><?php echo e(round($ware['amount'] * $ware['price_euro'] - $ware['tva_euro_buc'] * $ware['amount'], 2)); ?></td>
                                <td><?php echo e(round($ware['amount'] * $ware['price_lei'] - $ware['tva_lei_buc'] * $ware['amount'], 2)); ?></td>

                                <td><?php echo e(round($ware['tva_euro_buc'] * $ware['amount'], 2)); ?></td>
                                <td><?php echo e(round($ware['tva_lei_buc'] * $ware['amount'], 2)); ?></td>
                                
                                <td><?php echo e(round($ware['amount'] * $ware['price_lei'], 2)); ?></td>
                                <td><?php echo e(round($ware['amount'] * $ware['price_lei'], 2)); ?></td>

                                <?php
                                    $eu_wit_out_tva += round($ware['amount'] * $ware['price_lei'] - $ware['tva_euro_buc'] * $ware['amount'], 2);
                                    $lei_wit_out_tva += round($ware['amount'] * $ware['price_lei'] - $ware['tva_lei_buc'] * $ware['amount'], 2);

                                    $eu_tva += round($ware['tva_euro_buc'] * $ware['amount'], 2);
                                    $lei_tva += round($ware['tva_lei_buc'] * $ware['amount'], 2);

                                    $eu_with_tva += round($ware['amount'] * $ware['price_lei'], 2);
                                    $lei_with_tva += round($ware['amount'] * $ware['price_lei'], 2);


                                ?>

                            </tr>
                            <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="8"></td>
                            <td><?php echo e($eu_wit_out_tva); ?></td>
                            <td><?php echo e($lei_wit_out_tva); ?></td>
                            <td><?php echo e($eu_tva); ?></td>
                            <td><?php echo e($lei_tva); ?></td>
                            <td><?php echo e($eu_with_tva); ?></td>
                            <td><?php echo e($lei_with_tva); ?></td>

                        </tr>

                    </table>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div >
                        <button id="searchBtn" type="submit" class="btn btn-secondary"> Generare pdf</button>
                        <button id="searchBtn" type="submit"
                                class="btn btn-secondary btn-danger btn-flat bills-alert-delete">
                            Delete
                        </button>
                    </div>
        </div>


        <?php else: ?>
            <div class="alert alert-warning">
                <h5>Nici un client!</h5>
            </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/bills/bills_show.blade.php ENDPATH**/ ?>