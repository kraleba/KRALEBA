<?php $__env->startSection('content'); ?>

    <div>
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-right">
                    <a class="btn btn-secondary" href="<?php echo e(route('customers.create')); ?>"> ADAUGA CLIENT</a>
                </div>
            </div>

        </div>
    </div>
    <div class="container ">
        <div class="row searchFilter-custom card round3">

            <div class="col-lg-12 box-filter">
                <form action="<?php echo e(route('customers.index')); ?>" method="get">
                    <div>
                        <h4>SELECTEAZA:</h4>
                    </div>
                    <br>

                    <br>
                    <div class="input-group item-left filter-item1">
                        <div >
                            <div>                                
                                <input type='text'
                                id="find_customer"
                                name="customer_name"
                                placeholder="--Selecteaza un Client--"
                                class="form-control filter-control rounded-pill"
                                >
                            </div>
                        </div>

                        <div>
                            <div>
                                <select name="customer_type" id="department"
                                        class="form-control rounded-pill filter-control">
                                    
                                    <option value="customer"> Beneficiar</option>
                                    <option value="provider">Furnizor</option>
                                </select>
                            </div>
                        </div>
                    


                        <div>
                            <select name="category" id="department" class="form-control rounded-pill filter-control">

                                <option
                                    value="<?php echo e($filtering_criteria['category']->category_id ?? ''); ?>"> <?php echo e($filtering_criteria['category']->name ?? '-- Selecteaza o categorie --'); ?></option>

                                <?php $__currentLoopData = $furnace_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furnace_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option
                                        value="<?php echo e($furnace_category->category_id); ?>"><?php echo e($furnace_category->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>

                        <div>
                            <input type='text'
                                   name="subcategory"
                                   list="browsers"
                                   placeholder="--Selecteaza o subcategorie--"
                                   class="form-control filter-control rounded-pill"
                                   value="<?php echo e($filtering_criteria['subcategory'] ?? ''); ?>"
                            >

                            <datalist id="browsers" class="dropdown">

                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($subcategory->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>

                        </div>
                    </div>
                    

                    <div class="filter-item_OK ">
                        <button id="searchBtn" type="submit" class="btn btn-secondary"> OK</button>
                    </div>

                    <div class="pdf-style">

                        <?php if($customers): ?>
                            <button type="submit" name="downloadPDF" value="PDF" class="btn btn-info">SALVEAZA ca .pdf
                            </button>
                        <?php endif; ?>
                    </div>
                </form>

                <form>
                    <div class="revert-b">
                        <button type="submit" class="btn btn-secondary">REVERT</button>
                    </div>
                </form>
            </div>

        </div>
        
    </div>
    <!--end filter-->
    <br>

    <?php if($customers): ?>
        <div>
            <h3> <?php echo e($filter_title ?? 'Toti clientii'); ?></h3>
        </div>
    <?php endif; ?>
    
    <br>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    
    <?php if($customers): ?>
        <div>
            <ul class="list-body">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="list-group-item white-text rounded-pill" style=" border-radius: 0; height: 80px">

                        <div class="align">
                            <a href="<?php echo e(route('customers.show',$customer->id)); ?>">

                                <b><?php echo e($customer->name); ?> </b> /

                                <?php echo e($customer->uniqueCode); ?>


                                <?php if($customer->address): ?>
                                    /
                                <?php endif; ?>
                                <?php echo e($customer->address); ?>


                                <?php if($customer->city): ?>
                                    /
                                <?php endif; ?>
                                <?php echo e($customer->city); ?>


                                <?php if($customer->zipCode): ?>
                                    /
                                <?php endif; ?>
                                <?php echo e($customer->zipCode); ?>


                                <?php if($customer->country): ?>
                                    /
                                <?php endif; ?>
                                <?php echo e($customer->country); ?>

                            </a>
                        </div>
                        <div class="align">

                            <?php echo e($customer->cif); ?>


                            <?php if($customer->ocr): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->ocr); ?>


                            <?php if($customer->iban): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->iban); ?>


                            <?php if($customer->swift): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->swift); ?>


                            <?php if($customer->bank): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->bank); ?>


                        </div>

                        <div class="align">
                            <?php echo e($customer->contact); ?>


                            <?php if($customer->phone): ?>
                                /
                            <?php endif; ?>

                            <?php echo e($customer->phone); ?>


                            <?php if($customer->phone2): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->phone2); ?>


                            <?php if($customer->type): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->type); ?>


                            <?php if($customer->email): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->email); ?>


                            <?php if($customer->www): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->www); ?>


                            <?php if($customer->note): ?>
                                /
                            <?php endif; ?>
                            <?php echo e($customer->note); ?>


                        </div>

                        <div class="dropdown option-button">
                            <div class=" dropdown" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                 aria-haspopup="true" aria-expanded="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                     class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                    <path
                                        d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                                </svg>
                            </div>
                            <form action="<?php echo e(route('customers.destroy',$customer->id)); ?>" method="POST">

                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                    <a class="dropdown-item"
                                       href="<?php echo e(route('customers.edit', $customer->id)); ?>">Edit</a>

                                    <a class="dropdown-item"
                                       href="<?php echo e(route('bills.index', $customer->id)); ?>">Facturiile </a>

                                    <a class="dropdown-item" href="<?php echo e(route('wares.index', $customer->id)); ?>">
                                        Articole </a>


                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="dropdown-item">Delete</button>

                                </div>
                            </form>
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    <?php else: ?>
        <div class="alert alert-warning">
            <h5>Nici un client!</h5>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/KRALEBA/KRALEBA/resources/views/customers/index.blade.php ENDPATH**/ ?>