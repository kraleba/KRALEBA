<?php
//
//namespace App\Models;
//
//use Illuminate\Database\Eloquent\Factories\HasFactory;
//use Illuminate\Database\Eloquent\Model;
//
//class MarketingTemplateCategories extends Model
//{
//    use HasFactory;
//
//    protected $fillable = [
//        'parent_id',
//        'suffix',
//        'template_child_photo',
//        'created_at',
//        'updated_at'
//    ];
//}
